CREATE DATABASE SQL_DEMO_PROJECT

USE SQL_DEMO_PROJECT

CREATE SCHEMA SALES;
CREATE SCHEMA PRODUCTION;

--SALES--SCHEMA--
--1.--CUSTOMERS--TABLE--
CREATE TABLE Sales.Customers (
    Customer_ID INT PRIMARY KEY,
    First_Name VARCHAR(50)NOT NULL,
    Last_Name VARCHAR(50)NOT NULL,
    Phone VARCHAR(20),
    Email VARCHAR(100),
);
CREATE TABLE Sales.Customer_Address(
	Customer_ID INT PRIMARY KEY,
	Street VARCHAR(100),
	City VARCHAR(50),
	State VARCHAR(50),
	Zip_Code VARCHAR(20)
	FOREIGN KEY (Customer_ID) REFERENCES Sales.Customers(Customer_ID)
);
CREATE TABLE Sales.#Temp_Customers(
	customer_id INT PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	phone VARCHAR(50),
	email VARCHAR(256),
	street VARCHAR(100),
	city VARCHAR(50),
	state VARCHAR(50),
	zip_code VARCHAR(20)
);

		BULK INSERT Sales.#Temp_Customers
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\customers.csv'
			WITH(
				ROWTERMINATOR = '\n',
				FIELDTERMINATOR = ',',
				FIRSTROW = 2
		);

INSERT INTO Sales.Customers
SELECT 
	customer_id,
	first_name, 
	last_name, 
	iif(phone = 'NULL', null, phone) phone,
	email
FROM sales.#Temp_Customers

INSERT INTO Sales.Customer_Address
SELECT 
	customer_id,
	street,
	city,
	state,
	Zip_code
FROM SALES.#Temp_Customers
SELECT * FROM Sales.Customers;
SELECT * FROM Sales.Customer_Address;

--2.--ORDERS--TABLE--
CREATE TABLE Sales.Staging_Orders (
    Order_ID INT,
    Customer_ID INT, 
    Order_Status INT,
    Order_Date DATE,
    Required_Date DATE,
    Shipped_Date varchar(50),
    Store_ID INT,
    Staff_ID INT
);
		BULK INSERT Sales.Staging_Orders
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\orders.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2,
				KEEPNULLS
		);
CREATE TABLE Sales.Orders (
    Order_ID INT PRIMARY KEY,
    Customer_ID INT,
    Order_Status INT,
    Order_Date DATE NULL,
    Required_Date DATE NULL,
    Shipped_Date DATE NULL,
    Store_ID INT,
    Staff_ID INT,
    FOREIGN KEY (Customer_ID) REFERENCES Sales.Customers(Customer_ID),
    FOREIGN KEY (Store_ID) REFERENCES Sales.Stores(Store_ID),
    FOREIGN KEY (Staff_ID) REFERENCES Sales.Staffs(Staff_ID)
);
INSERT INTO SALES.orders (
    Order_ID,
    Customer_ID,
    Order_Status,
    Order_Date,
    Required_Date,
    Store_ID,
    Staff_ID,
    Shipped_Date
)

SELECT
    Order_ID,
    Customer_ID,
    Order_Status,
    Order_Date,
    Required_Date,
    Store_ID,
    Staff_ID,
    CAST(NULLIF(Shipped_Date, 'NULL') AS DATE)
FROM SALES.staging_orders;
SELECT * FROM Sales.Orders

--3.--ORDER_ITEMS--TABLE--
CREATE TABLE Sales.OrderItems (
    Order_ID INT,
    Item_ID INT,
    Product_ID INT,
    Quantity INT,
    List_price DECIMAL(10,2),
    Discount DECIMAL(10,2),
    PRIMARY KEY (Order_ID, Item_ID),
    FOREIGN KEY (Order_ID) REFERENCES Sales.Orders(Order_ID),
    FOREIGN KEY (Product_ID) REFERENCES Production.Products(Product_ID)
);
		BULK INSERT Sales.OrderItems
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\order_items.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2,
				KEEPNULLS
		);

SELECT * FROM Sales.OrderItems

--4.--STORES--TABLE--
CREATE TABLE Sales.Stores (
    Store_ID INT PRIMARY KEY,
    Store_Name VARCHAR(100)NOT NULL,
    Phone VARCHAR(20),
    Email VARCHAR(100),
    Street VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
    Zip_Code VARCHAR(10)
);
		BULK INSERT Sales.Stores
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\stores.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM Sales.Stores

--5.--STAFFS--TABLE--
CREATE TABLE Sales.Staffs (
    Staff_id INT PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Email VARCHAR(100),
    Phone VARCHAR(20),
    Active INT,
    Store_ID INT,
    Manager_ID INT,
    FOREIGN KEY (Store_ID) REFERENCES Sales.Stores(Store_ID),
    FOREIGN KEY (Manager_ID) REFERENCES Sales.Staffs(Staff_ID)
);
		BULK INSERT Sales.Staffs
		   FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\staffs.csv'
		   WITH (
			   FIELDTERMINATOR = ',',
			   ROWTERMINATOR = '\n',
			   FIRSTROW = 2
	   );
SELECT * FROM SALES.Staffs

--PRODUCTION--SCHEMA--

--6.--BRANDS--TABLE--
CREATE TABLE Production.Brands (
    Brand_ID INT PRIMARY KEY,
    Brand_Name VARCHAR(100) NOT NULL
);
		BULK INSERT Production.Brands
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\brands.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM PRODUCTION.Brands

--7.--CATEGORY--TABLE--
CREATE TABLE Production.Categories (
    Category_ID INT PRIMARY KEY,
    Category_Name VARCHAR(100) NOT NULL
);
		BULK INSERT Production.Categories
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\categories.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM PRODUCTION.Categories

--8.--PRODUCTs--TABLE--
CREATE TABLE Production.Products (
	Product_ID INT PRIMARY KEY,
	Product_Name VARCHAR(100),
	Brand_ID INT,
	Category_ID INT,
	Model_year DATE,
	List_price DECIMAL(10, 2),
	FOREIGN KEY (Brand_ID) REFERENCES Production.Brands(Brand_ID),
    FOREIGN KEY (Category_ID) REFERENCES Production.Categories(Category_ID)
);
		BULK INSERT Production.Products
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\products.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM Production.Products

--9.--STOCKS-TABLE--
 CREATE TABLE Production.Stocks (
    Store_ID INT,
    Product_ID INT,
    Quantity INT,
    PRIMARY KEY (Store_ID, Product_ID),
    FOREIGN KEY (Store_ID) REFERENCES Sales.Stores(Store_ID),
    FOREIGN KEY (Product_ID) REFERENCES Production.Products(Product_ID)
);
		BULK INSERT Production.Stocks
		   FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\stocks.csv'
		   WITH (
			   FIELDTERMINATOR = ',',
			   ROWTERMINATOR = '\n',
			   FIRSTROW = 2
		   );
SELECT * FROM Production.Stocks