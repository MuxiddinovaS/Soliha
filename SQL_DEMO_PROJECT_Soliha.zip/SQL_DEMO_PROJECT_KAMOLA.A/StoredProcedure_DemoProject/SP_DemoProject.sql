﻿USE SQL_DEMO_PROJECT

CREATE PROCEDURE sp_CalculateStoreKPI
    @StoreID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        s.store_id,
        s.store_name,
        SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS TotalSales,
        COUNT(DISTINCT o.order_id) AS TotalOrders,
        CASE 
            WHEN COUNT(DISTINCT o.order_id) = 0 THEN 0
            ELSE ROUND(SUM(oi.quantity * oi.list_price * (1 - oi.discount)) / COUNT(DISTINCT o.order_id), 2)
        END AS AvgOrderValue,
       (SELECT COUNT(*) FROM sales.Staffs st WHERE st.store_id = s.store_id) AS StaffCount,
	           (SELECT SUM(st.quantity * p.list_price)
         FROM production.Stocks st
         JOIN production.Products p ON st.product_id = p.product_id
         WHERE st.store_id = s.store_id) AS InventoryValue

    FROM sales.Stores s
    LEFT JOIN sales.Orders o ON s.store_id = o.store_id
    LEFT JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    WHERE s.store_id = @StoreID
    GROUP BY s.store_id, s.store_name;
END;

------------------------------------------------
CREATE PROCEDURE sp_GenerateRestockList
    @Threshold INT = 10  -- Default threshold for restocking
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        s.store_id,
        st.store_name,
        p.product_id,
        p.product_name,
        s.quantity AS current_stock,
        p.list_price,
        b.brand_name,
        c.category_name
    FROM production.Stocks s
    INNER JOIN production.Products p ON s.product_id = p.product_id
    INNER JOIN Sales.Stores st ON s.store_id = st.store_id
    INNER JOIN production.brands b ON p.brand_id = b.brand_id
    INNER JOIN production.Categories c ON p.category_id = c.category_id
    WHERE s.quantity < @Threshold
    ORDER BY s.store_id, s.quantity;
END;



------------------------------------
--sp_CompareSalesYearOverYear
--Input: @year1, @year2
--Output: Revenue and order count comparison per month
CREATE PROCEDURE sp_CompareSalesYearOverYear
    @year1 INT,
    @year2 INT
AS
BEGIN
    SELECT
        MONTH(o.order_date) AS month,
        YEAR(o.order_date) AS year,
        SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS revenue,
        COUNT(DISTINCT o.order_id) AS orders
    FROM sales.Orders o
    JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    WHERE YEAR(o.order_date) IN (@year1, @year2)
    GROUP BY MONTH(o.order_date), YEAR(o.order_date)
    ORDER BY month, year;
END;

----------------------------



CREATE PROCEDURE sp_GetCustomerProfile
    @CustomerId INT
AS
BEGIN
    -- Return total orders and total spend by the customer
    SELECT 
        c.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        COUNT(DISTINCT o.order_id) AS total_orders,
        SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_spent
    FROM sales.Customers c
    JOIN sales.Orders o ON c.customer_id = o.customer_id
    JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    WHERE c.customer_id = @CustomerId
    GROUP BY c.customer_id, c.first_name, c.last_name;

    -- Return the top 3 most frequently bought products
    SELECT TOP 3
        p.product_id,
        p.product_name,
        SUM(oi.quantity) AS total_quantity
    FROM sales.Orders o
    JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    JOIN production.Products p ON oi.product_id = p.product_id
    WHERE o.customer_id = @CustomerId
    GROUP BY p.product_id, p.product_name
    ORDER BY total_quantity DESC;
END;

EXEC sp_GetCustomerProfile @CustomerId = 101;
-----------------------------------------------
--addition--

CREATE PROCEDURE sp_StaffRevenueContribution
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    SELECT 
        s.First_Name,
        SUM(oi.Quantity * oi.List_price) AS RevenueGenerated
    FROM 
        sales.Orders o
    JOIN sales.Staffs s ON o.Staff_ID = s.Staff_id
    JOIN sales.OrderItems oi ON o.Order_ID = oi.Order_ID
    WHERE 
        o.Order_Date BETWEEN @StartDate AND @EndDate
        AND o.Order_Status = 3 -- assuming 3 = Completed
    GROUP BY s.First_Name;
END;
EXEC sp_StaffRevenueContribution 
    @StartDate = '2016-01-01', 
    @EndDate = '2018-12-31';
--🎯 BU NIMA UCHUN FOYDALI?
--Rahbariyat uchun: qaysi xodim samaraliroq ishlayotganini ko‘rish
--Mukofotlash: eng ko‘p daromad olib kelgan xodimlarga bonus yoki rag‘batlantirish
--Tahlil: qaysi davrlarda qaysi xodimlar faollik ko‘rsatganini aniqlash
