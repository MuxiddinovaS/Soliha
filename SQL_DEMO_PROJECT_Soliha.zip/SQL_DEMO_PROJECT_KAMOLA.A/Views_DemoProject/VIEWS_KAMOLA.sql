USE SQL_DEMO_PROJECT
--VIEWS--
CREATE VIEW vw_StoreSalesSummary AS
SELECT 
	ST.Store_ID,
	Store_Name, 
	ROUND(SUM((quantity * list_price)*(1-discount)), 2) Revenue, 
	COUNT(DISTINCT ORD.Order_ID) Orders,
	ROUND(SUM((quantity * list_price)*(1-discount))/COUNT(DISTINCT ORD.Order_ID), 2) AOV
FROM Sales.Stores ST
JOIN Sales.Orders ORD
ON St.Store_ID = ORD.Store_ID
JOIN Sales.OrderItems OI
ON ORD.order_ID = OI.Order_ID
GROUP BY 
	ST.Store_ID,
	Store_Name;
SELECT * FROM vw_StoreSalesSummary;
--Bu ko�rinish kompaniyaning har bir do�koni bo�yicha natijadorligini (daromad, buyurtmalar soni va o�rtacha buyurtma qiymati) ko�rishga imkon beradi.
--Buyurtmalar soni orqali har bir do�konda nechta buyurtma bo�lganini ko�rib, ularni solishtirib, qaysi biri eng yaxshi ishlayotganini aniqlash mumkin. 
--Eng yaxshi ishlayotgan do�konga nafaqat mijozlarga, balki xodimlarga ham rag�batlantirishlar (bonuslar) taklif qilish mumkin.
--AOV � ya�ni o�rtacha buyurtma qiymati � bu muhim KPI ko�rsatkich bo�lib, mijozlarning xarid qilish odatlarini tahlil qilishga yordam beradi.
--Bu tushuncha kompaniyaga mijozlarni AOVdan yuqori xarid qilishga undovchi strategiyalar ishlab chiqishga yordam beradi. Masalan, bepul yetkazib berish, bonus mahsulot yoki chegirma taklif qilish mumkin.
--Ushbu holatda uchta do�kon uchun AOV mos ravishda 4900, 4600 va 4700. Biz, masalan, 5000 so�mdan yuqori buyurtmalarga bepul yetkazib berish yoki chegirma berishni taklif qilishimiz mumkin.
--------------------------------
--(addition to view)--
CREATE VIEW vw_CustomerLifetimeValue AS
SELECT
    C.Customer_ID,
    C.First_name + ' ' + C.Last_name AS Customer_Name,
    COUNT(DISTINCT o.order_id) AS Total_Orders,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Total_Revenue,
    AVG(oi.quantity * oi.list_price * (1 - oi.discount)) AS Avg_Item_Value,
    MIN(o.order_date) AS First_order_date,
    MAX(o.order_date) AS Last_order_date
FROM Sales.Customers c
JOIN SALES.Orders o ON c.customer_id = o.customer_id
JOIN Sales.OrderItems oi ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.first_name, c.last_name;
SELECT * FROM vw_CustomerLifetimeValue;
--Bu stored procedure ikki yil orasidagi savdoni solishtirish uchun ishlatiladi. U orders va order_items jadvalidan foydalanib, har oy uchun jami savdoni hisoblab beradi.
--Parametr sifatida ikkita yil oladi (@Year1, @Year2).
--Har bir oy bo�yicha:
--@Year1 yildagi savdoni @Year2 yildagi savdoni hisoblaydi. Bu orqali siz 2016-yil yanvaridagi savdoni 2018-yil yanvaridagisi bilan solishtirishingiz mumkin.
--Yuqori qiymatga ega mijozlarni aniqlash / tushunish
--Yangi va sodiq mijozlarni ajratib ko�rsatish
--Mijozlarni ushlab qolish tendensiyalarini ko�rish
--Har bir mijoz uchun quyidagilarni ko�rsatadi:
-----------------------------------------------------

CREATE VIEW vw_StaffPerformance AS
SELECT
    s.staff_id,
    s.first_name + ' ' + s.last_name AS staff_name,
    COUNT(DISTINCT o.order_id) AS total_orders,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_revenue
FROM Sales.Staffs S
JOIN Sales.Orders O
	ON s.staff_id = o.staff_id
JOIN Sales.OrderItems OI 
	ON o.order_id = oi.order_id
GROUP BY s.staff_id, s.first_name, s.last_name;
SELECT * FROM vw_StaffPerformance;
--Orders and revenue handled per staff
--Eng faol xodimlarni aniqlaysiz
--Kim ko�p daromad keltirganini ko�rasiz
--Mukofot tizimlari yoki rag�batlantirish yaratishingiz mumkin
--Kamroq samarali xodimlarga e�tibor qaratishingiz mumkin
---------------------------------------------------------
CREATE VIEW vw_InventoryStatus2 AS
SELECT
  St.Store_ID,
  S.Store_Name,
  P.Product_ID,
  P.Product_Name,
  C.Category_Name,
  B.Brand_Name,
  St.Quantity,
  List_Price*Quantity as Total_Value_of_low_stock
FROM production.Stocks AS St
JOIN production.Products as P
  ON St.Product_ID = P.Product_ID
JOIN sales.Stores as S
  ON St.Store_ID = S.Store_ID
JOIN production.Brands as B
  ON P.Brand_ID = B.Brand_ID
JOIN production.Categories AS C
  ON P.Category_ID = C.Category_ID
WHERE
  St.Quantity < 10;
SELECT * FROM vw_InventoryStatus2
--Bu so�rov sizga har bir do�konda zaxiradagi miqdori 10 donadan kam bo�lgan mahsulotlar haqida batafsil ma�lumot beradi.
--Ya�ni, siz Bikers firmasining kam qolgan mahsulot zaxiralarini ko�ryapsiz.
--Do�kon menejerlari: qaysi mahsulotlar tugayapti, zudlik bilan buyurtma berish kerakmi yoki yo�qmi, bilishadi.
--Brend menejeri: aynan Bikers brendining zaxirasi qanday holatda ekanligini nazorat qiladi.
--Marketing va Savdo jamoasi: kam qolgan, ammo yuqori talabdagi mahsulotlarga aksiyalar o�ylab topishlari mumkin.
----------------------------------------
--vw_RegionalTrends: Revenue by city or region--
CREATE VIEW vw_RegionalTrends AS
SELECT
    S.City,
    S.State,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Total_Revenue
FROM
    Sales.OrderItems as OI
JOIN
    Sales.Orders O ON oi.order_id = o.order_id
JOIN
    Sales.Stores S ON o.store_id = s.store_id
GROUP BY
    s.city, s.state;
SELECT * FROM vw_RegionalTrends;
--Siz bu so�rov (query) orqali qaysi shahar va shtatda qancha umumiy daromad (sotuv) tushganini aniqlayapsiz.
--Qaysi hudud eng ko�p sotuv qilayotganini ko�rish
--Past sotuvli hududlar bo�yicha sabab tahlil qilish
--Marketing, reklama, chegirmalarni aniq joylarga yo�naltirish
--Hududlar bo�yicha strategik reja tuzish (masalan, yangi filial ochish, yopish, kampaniyalar
------------------------------------------
CREATE VIEW vw_TopSellingProducts AS
SELECT
    p.product_id,
    p.product_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales,
    RANK() OVER (ORDER BY SUM(oi.quantity * oi.list_price * (1 - oi.discount)) DESC) AS sales_rank
FROM
    Sales.OrderItems as oi
JOIN
    Production.Products as p ON oi.product_id = p.product_id
GROUP BY
    p.product_id, p.product_name;
SELECT * FROM vw_TopSellingProducts;
--Siz bu yerda kompaniyangizdagi mahsulotlar orasida eng ko�p daromad keltirganlarini topyapsiz va ularni daromadga qarab reytinglab chiqyapsiz.
--Eng ko�p daromad keltirayotgan mahsulotlar reytingi
--Qaysi mahsulotlar eng yaxshi sotilmoqda
--Qaysi mahsulotlarga e�tibor qaratish kerakligini aniqlashda yordam beradi
--------------------------------------------

CREATE VIEW vw_SalesByCategory AS
SELECT
    c.category_id,
    c.category_name,
    SUM(oi.quantity) AS total_quantity_sold,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales_revenue
FROM
    Sales.OrderItems AS oi
JOIN
    Production.Products AS p ON oi.product_id = p.product_id
JOIN
    Production.Categories AS c ON p.category_id = c.category_id
GROUP BY
    c.category_id, c.category_name;
SELECT * FROM vw_SalesByCategory;
--Qaysi mahsulot kategoriyasi eng ko�p daromad keltirgan
--Qaysi turdagi mahsulotlar eng ko�p sotilgan
--Marketing va biznes qarorlar uchun:
--Qaysi kategoriyaga ko�proq e�tibor qaratish kerak
--Qaysi mahsulotlarni omborda ko�proq saqlash kerak
--Qaysi kategoriyalar uchun reklama yoki chegirma kampaniyasi o�tkazish kerak
--Demak, Bikes kategoriyasi eng ko�p sotilgan va eng ko�p daromad keltirgan. Bu sizga biznes strategiyasini to�g�ri yo�naltirishga yordam beradi.
------------------------------------------
--addition
CREATE VIEW vw_TopBrands AS
SELECT
    b.brand_id,
    b.brand_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales,
    RANK() OVER (ORDER BY SUM(oi.quantity * oi.list_price * (1 - oi.discount)) DESC) AS brand_rank
FROM
    Sales.OrderItems AS oi
JOIN
    Production.Products AS p ON oi.product_id = p.product_id
JOIN
    Production.Brands AS b ON p.brand_id = b.brand_id
GROUP BY
    b.brand_id, b.brand_name;
SELECT * FROM vw_TopBrands;
--Siz bu yerda kompaniyangizdagi barcha brendlar orasida eng ko�p daromad keltirganlarini aniqlayapsiz.
--Ya�ni qaysi brend eng ko�p sotilgan va eng ko�p daromad keltirganini topyapsiz, va ularni reytinglab chiqyapsiz (1-o�rin eng yuqori daromadli brend).
--Bu view yordamida siz quyidagilarni aniqlaysiz:
--Eng ko�p daromad keltirgan brendlar qaysilar?
--Qaysi brendlarga ko�proq e�tibor qaratish kerak?
--Marketing yoki sotuv strategiyasini qaysi brendlar uchun kuchaytirish kerak?
--Zaxirada ko�proq saqlash kerak bo�lgan brendlar qaysilar?
----------------------------------------------------------
