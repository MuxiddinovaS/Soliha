﻿USE SQL_DEMO_PROJECT

--KPI DEFINITIONS & CALCULATIONS
--1. Total Revenue
--Insight: Overall company sales performance.
SELECT 
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_revenue
FROM SALES.OrderItems oi;
--Automate with:
CREATE VIEW vw_TotalRevenue AS
SELECT SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_revenue
FROM SALES.OrderItems oi;
-------------------
--2. Average Order Value (AOV)
SELECT 
    AVG(order_total) AS avg_order_value
FROM (
    SELECT 
        o.order_id,
        SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS order_total
    FROM SALES.Orders o
    JOIN SALES.OrderItems oi ON o.order_id = oi.order_id
    GROUP BY o.order_id
) AS sub;
------------------------------------
--3.Inventory Turnover
--Insight: How efficiently inventory is sold.
--Formula:
--Inventory Turnover = COGS / Avg Inventory
--Assume COGS ≈ sales revenue, and average inventory can be simplified if you don’t track historical stock.
SELECT 
    p.category_id,
    c.category_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) / NULLIF(AVG(s.quantity), 0) AS inventory_turnover
FROM sales.OrderItems oi
JOIN production.Products p ON oi.product_id = p.product_id
JOIN production.Categories c ON p.category_id = c.category_id
JOIN production.Stocks s ON p.product_id = s.product_id
GROUP BY p.category_id, c.category_name;
-----------------------------------------
--4.Product Return Rate (if applicable)
--Insight: Product quality or customer satisfaction
--Only if you have a returns table — simulate logic:
--SELECT 
--    product_id,
--    COUNT(*) * 1.0 / NULLIF((SELECT COUNT(*) FROM order_items WHERE product_id = r.product_id), 0) AS return_rate
--FROM returns r
--GROUP BY product_id;
-----------------------------------

--5. Revenue by Store
--Insight: Store-level performance

CREATE VIEW vw_StoreRevenue AS
SELECT 
    s.store_id,
    s.store_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS store_revenue
FROM sales.Stores s
JOIN sales.Orders o ON s.store_id = o.store_id
JOIN sales.OrderItems oi ON o.order_id = oi.order_id
GROUP BY s.store_id, s.store_name;
--------------------------------------------

--6. Gross Profit by Category
--Gross Profit = Revenue – Cost
--Assume cost is 60% of list price (if actual cost unavailable)

CREATE VIEW vw_GrossProfitByCategory AS
SELECT 
    c.category_id,
    c.category_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS revenue,
    SUM(oi.quantity * oi.list_price * 0.6) AS estimated_cost,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) - SUM(oi.quantity * oi.list_price * 0.6) AS gross_profit
FROM sales.OrderItems oi
JOIN production.Products p ON oi.product_id = p.product_id
JOIN production.Categories c ON p.category_id = c.category_id
GROUP BY c.category_id, c.category_name;
-----------------------------------------

--7. Sales by Brand
--Insight: Vendor performance
CREATE VIEW vw_SalesByBrand AS
SELECT 
    b.brand_id,
    b.brand_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales
FROM sales.OrderItems oi
JOIN production.Products p ON oi.product_id = p.product_id
JOIN production.Brands b ON p.brand_id = b.brand_id
GROUP BY b.brand_id, b.brand_name;
-------------------------------

--8. Staff Revenue Contribution
--Insight: Productivity of staff members
CREATE VIEW vw_StaffRevenueContribution AS
SELECT 
    st.staff_id,
    st.first_name + ' ' + st.last_name AS staff_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS revenue_handled,
    COUNT(DISTINCT o.order_id) AS orders_handled
FROM sales.Staffs st
JOIN sales.Orders o ON st.staff_id = o.staff_id
JOIN sales.OrderItems oi ON o.order_id = oi.order_id
GROUP BY st.staff_id, st.first_name, st.last_name;
--------------------------------------------

--9.Automation with Stored Procedure (Example)
CREATE PROCEDURE sp_CompanyKPI
AS
BEGIN
    -- Total revenue
    SELECT 'Total Revenue' AS KPI, SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Value
    FROM order_items oi

    UNION ALL

    -- AOV
    SELECT 'Average Order Value', 
        AVG(order_total)
    FROM (
        SELECT o.order_id, SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS order_total
        FROM sales.Orders o
        JOIN sales.OrderItems oi ON o.order_id = oi.order_id
        GROUP BY o.order_id
    ) sub;
END;
