CREATE DATABASE SQL_DEMO_PROJECT

USE SQL_DEMO_PROJECT

CREATE SCHEMA SALES;
CREATE SCHEMA PRODUCTION;

--SALES--SCHEMA--
--1.--CUSTOMERS--TABLE--
CREATE TABLE Sales.Customers (
    Customer_ID INT PRIMARY KEY,
    First_Name VARCHAR(50)NOT NULL,
    Last_Name VARCHAR(50)NOT NULL,
    Phone VARCHAR(20),
    Email VARCHAR(100),
);
CREATE TABLE Sales.Customer_Address(
	Customer_ID INT PRIMARY KEY,
	Street VARCHAR(100),
	City VARCHAR(50),
	State VARCHAR(50),
	Zip_Code VARCHAR(20)
	FOREIGN KEY (Customer_ID) REFERENCES Sales.Customers(Customer_ID)
);
CREATE TABLE Sales.#Temp_Customers(
	customer_id INT PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	phone VARCHAR(50),
	email VARCHAR(256),
	street VARCHAR(100),
	city VARCHAR(50),
	state VARCHAR(50),
	zip_code VARCHAR(20)
);

		BULK INSERT Sales.#Temp_Customers
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\customers.csv'
			WITH(
				ROWTERMINATOR = '\n',
				FIELDTERMINATOR = ',',
				FIRSTROW = 2
		);

INSERT INTO Sales.Customers
SELECT 
	customer_id,
	first_name, 
	last_name, 
	iif(phone = 'NULL', null, phone) phone,
	email
FROM sales.#Temp_Customers

INSERT INTO Sales.Customer_Address
SELECT 
	customer_id,
	street,
	city,
	state,
	Zip_code
FROM SALES.#Temp_Customers
SELECT * FROM Sales.Customers;
SELECT * FROM Sales.Customer_Address;

--2.--ORDERS--TABLE--
CREATE TABLE Sales.Staging_Orders (
    Order_ID INT,
    Customer_ID INT, 
    Order_Status INT,
    Order_Date DATE,
    Required_Date DATE,
    Shipped_Date varchar(50),
    Store_ID INT,
    Staff_ID INT
);
		BULK INSERT Sales.Staging_Orders
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\orders.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2,
				KEEPNULLS
		);
CREATE TABLE Sales.Orders (
    Order_ID INT PRIMARY KEY,
    Customer_ID INT,
    Order_Status INT,
    Order_Date DATE NULL,
    Required_Date DATE NULL,
    Shipped_Date DATE NULL,
    Store_ID INT,
    Staff_ID INT,
    FOREIGN KEY (Customer_ID) REFERENCES Sales.Customers(Customer_ID),
    FOREIGN KEY (Store_ID) REFERENCES Sales.Stores(Store_ID),
    FOREIGN KEY (Staff_ID) REFERENCES Sales.Staffs(Staff_ID)
);
INSERT INTO SALES.orders (
    Order_ID,
    Customer_ID,
    Order_Status,
    Order_Date,
    Required_Date,
    Store_ID,
    Staff_ID,
    Shipped_Date
)

SELECT
    Order_ID,
    Customer_ID,
    Order_Status,
    Order_Date,
    Required_Date,
    Store_ID,
    Staff_ID,
    CAST(NULLIF(Shipped_Date, 'NULL') AS DATE)
FROM SALES.staging_orders;
SELECT * FROM Sales.Orders

--3.--ORDER_ITEMS--TABLE--
CREATE TABLE Sales.OrderItems (
    Order_ID INT,
    Item_ID INT,
    Product_ID INT,
    Quantity INT,
    List_price DECIMAL(10,2),
    Discount DECIMAL(10,2),
    PRIMARY KEY (Order_ID, Item_ID),
    FOREIGN KEY (Order_ID) REFERENCES Sales.Orders(Order_ID),
    FOREIGN KEY (Product_ID) REFERENCES Production.Products(Product_ID)
);
		BULK INSERT Sales.OrderItems
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\order_items.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2,
				KEEPNULLS
		);

SELECT * FROM Sales.OrderItems

--4.--STORES--TABLE--
CREATE TABLE Sales.Stores (
    Store_ID INT PRIMARY KEY,
    Store_Name VARCHAR(100)NOT NULL,
    Phone VARCHAR(20),
    Email VARCHAR(100),
    Street VARCHAR(100),
    City VARCHAR(50),
    State VARCHAR(50),
    Zip_Code VARCHAR(10)
);
		BULK INSERT Sales.Stores
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\stores.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM Sales.Stores

--5.--STAFFS--TABLE--
CREATE TABLE Sales.Staffs (
    Staff_id INT PRIMARY KEY,
    First_Name VARCHAR(50) NOT NULL,
    Last_Name VARCHAR(50) NOT NULL,
    Email VARCHAR(100),
    Phone VARCHAR(20),
    Active INT,
    Store_ID INT,
    Manager_ID INT,
    FOREIGN KEY (Store_ID) REFERENCES Sales.Stores(Store_ID),
    FOREIGN KEY (Manager_ID) REFERENCES Sales.Staffs(Staff_ID)
);
		BULK INSERT Sales.Staffs
		   FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\staffs.csv'
		   WITH (
			   FIELDTERMINATOR = ',',
			   ROWTERMINATOR = '\n',
			   FIRSTROW = 2
	   );
SELECT * FROM SALES.Staffs

--PRODUCTION--SCHEMA--

--6.--BRANDS--TABLE--
CREATE TABLE Production.Brands (
    Brand_ID INT PRIMARY KEY,
    Brand_Name VARCHAR(100) NOT NULL
);
		BULK INSERT Production.Brands
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\brands.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM PRODUCTION.Brands

--7.--CATEGORY--TABLE--
CREATE TABLE Production.Categories (
    Category_ID INT PRIMARY KEY,
    Category_Name VARCHAR(100) NOT NULL
);
		BULK INSERT Production.Categories
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\categories.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM PRODUCTION.Categories

--8.--PRODUCTs--TABLE--
CREATE TABLE Production.Products (
	Product_ID INT PRIMARY KEY,
	Product_Name VARCHAR(100),
	Brand_ID INT,
	Category_ID INT,
	Model_year DATE,
	List_price DECIMAL(10, 2),
	FOREIGN KEY (Brand_ID) REFERENCES Production.Brands(Brand_ID),
    FOREIGN KEY (Category_ID) REFERENCES Production.Categories(Category_ID)
);
		BULK INSERT Production.Products
			FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\products.csv'
			WITH (
				FIELDTERMINATOR = ',',
				ROWTERMINATOR = '\n',
				FIRSTROW = 2
		);
SELECT * FROM Production.Products

--9.--STOCKS-TABLE--
 CREATE TABLE Production.Stocks (
    Store_ID INT,
    Product_ID INT,
    Quantity INT,
    PRIMARY KEY (Store_ID, Product_ID),
    FOREIGN KEY (Store_ID) REFERENCES Sales.Stores(Store_ID),
    FOREIGN KEY (Product_ID) REFERENCES Production.Products(Product_ID)
);
		BULK INSERT Production.Stocks
		   FROM 'C:\Users\isfan\OneDrive\Desktop\SQL_DEMO_PROJECT_KAMOLA.A\stocks.csv'
		   WITH (
			   FIELDTERMINATOR = ',',
			   ROWTERMINATOR = '\n',
			   FIRSTROW = 2
		   );
SELECT * FROM Production.Stocks



----------------------------------------------------------------------------
----------------------------------------------------------------------------

CREATE VIEW vw_StoreSalesSummary AS
SELECT 
	ST.Store_ID,
	Store_Name, 
	ROUND(SUM((quantity * list_price)*(1-discount)), 2) Revenue, 
	COUNT(DISTINCT ORD.Order_ID) Orders,
	ROUND(SUM((quantity * list_price)*(1-discount))/COUNT(DISTINCT ORD.Order_ID), 2) AOV
FROM Sales.Stores ST
JOIN Sales.Orders ORD
ON St.Store_ID = ORD.Store_ID
JOIN Sales.OrderItems OI
ON ORD.order_ID = OI.Order_ID
GROUP BY 
	ST.Store_ID,
	Store_Name;
SELECT * FROM vw_StoreSalesSummary;


CREATE VIEW vw_CustomerLifetimeValue AS
SELECT
    C.Customer_ID,
    C.First_name + ' ' + C.Last_name AS Customer_Name,
    COUNT(DISTINCT o.order_id) AS Total_Orders,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Total_Revenue,
    AVG(oi.quantity * oi.list_price * (1 - oi.discount)) AS Avg_Item_Value,
    MIN(o.order_date) AS First_order_date,
    MAX(o.order_date) AS Last_order_date
FROM Sales.Customers c
JOIN SALES.Orders o ON c.customer_id = o.customer_id
JOIN Sales.OrderItems oi ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.first_name, c.last_name;
SELECT * FROM vw_CustomerLifetimeValue;



CREATE VIEW vw_StaffPerformance AS
SELECT
    s.staff_id,
    s.first_name + ' ' + s.last_name AS staff_name,
    COUNT(DISTINCT o.order_id) AS total_orders,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_revenue
FROM Sales.Staffs S
JOIN Sales.Orders O
	ON s.staff_id = o.staff_id
JOIN Sales.OrderItems OI 
	ON o.order_id = oi.order_id
GROUP BY s.staff_id, s.first_name, s.last_name;
SELECT * FROM vw_StaffPerformance;



CREATE VIEW vw_InventoryStatus2 AS
SELECT
  St.Store_ID,
  S.Store_Name,
  P.Product_ID,
  P.Product_Name,
  C.Category_Name,
  B.Brand_Name,
  St.Quantity,
  List_Price*Quantity as Total_Value_of_low_stock
FROM production.Stocks AS St
JOIN production.Products as P
  ON St.Product_ID = P.Product_ID
JOIN sales.Stores as S
  ON St.Store_ID = S.Store_ID
JOIN production.Brands as B
  ON P.Brand_ID = B.Brand_ID
JOIN production.Categories AS C
  ON P.Category_ID = C.Category_ID
WHERE
  St.Quantity < 10;
SELECT * FROM vw_InventoryStatus2



CREATE VIEW vw_RegionalTrends AS
SELECT
    S.City,
    S.State,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Total_Revenue
FROM
    Sales.OrderItems as OI
JOIN
    Sales.Orders O ON oi.order_id = o.order_id
JOIN
    Sales.Stores S ON o.store_id = s.store_id
GROUP BY
    s.city, s.state;
SELECT * FROM vw_RegionalTrends;



CREATE VIEW vw_TopSellingProducts AS
SELECT
    p.product_id,
    p.product_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales,
    RANK() OVER (ORDER BY SUM(oi.quantity * oi.list_price * (1 - oi.discount)) DESC) AS sales_rank
FROM
    Sales.OrderItems as oi
JOIN
    Production.Products as p ON oi.product_id = p.product_id
GROUP BY
    p.product_id, p.product_name;
SELECT * FROM vw_TopSellingProducts;





CREATE VIEW vw_SalesByCategory AS
SELECT
    c.category_id,
    c.category_name,
    SUM(oi.quantity) AS total_quantity_sold,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales_revenue
FROM
    Sales.OrderItems AS oi
JOIN
    Production.Products AS p ON oi.product_id = p.product_id
JOIN
    Production.Categories AS c ON p.category_id = c.category_id
GROUP BY
    c.category_id, c.category_name;
SELECT * FROM vw_SalesByCategory;




CREATE VIEW vw_TopBrands AS
SELECT
    b.brand_id,
    b.brand_name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_sales,
    RANK() OVER (ORDER BY SUM(oi.quantity * oi.list_price * (1 - oi.discount)) DESC) AS brand_rank
FROM
    Sales.OrderItems AS oi
JOIN
    Production.Products AS p ON oi.product_id = p.product_id
JOIN
    Production.Brands AS b ON p.brand_id = b.brand_id
GROUP BY
    b.brand_id, b.brand_name;
SELECT * FROM vw_TopBrands;



------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------

USE SQL_DEMO_PROJECT

CREATE PROCEDURE sp_CalculateStoreKPI
    @StoreID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        s.store_id,
        s.store_name,
        SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS TotalSales,
        COUNT(DISTINCT o.order_id) AS TotalOrders,
        CASE 
            WHEN COUNT(DISTINCT o.order_id) = 0 THEN 0
            ELSE ROUND(SUM(oi.quantity * oi.list_price * (1 - oi.discount)) / COUNT(DISTINCT o.order_id), 2)
        END AS AvgOrderValue,
       (SELECT COUNT(*) FROM sales.Staffs st WHERE st.store_id = s.store_id) AS StaffCount,
	           (SELECT SUM(st.quantity * p.list_price)
         FROM production.Stocks st
         JOIN production.Products p ON st.product_id = p.product_id
         WHERE st.store_id = s.store_id) AS InventoryValue

    FROM sales.Stores s
    LEFT JOIN sales.Orders o ON s.store_id = o.store_id
    LEFT JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    WHERE s.store_id = @StoreID
    GROUP BY s.store_id, s.store_name;
END;

------------------------------------------------
CREATE PROCEDURE sp_GenerateRestockList
    @Threshold INT = 10  -- Default threshold for restocking
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        s.store_id,
        st.store_name,
        p.product_id,
        p.product_name,
        s.quantity AS current_stock,
        p.list_price,
        b.brand_name,
        c.category_name
    FROM production.Stocks s
    INNER JOIN production.Products p ON s.product_id = p.product_id
    INNER JOIN Sales.Stores st ON s.store_id = st.store_id
    INNER JOIN production.brands b ON p.brand_id = b.brand_id
    INNER JOIN production.Categories c ON p.category_id = c.category_id
    WHERE s.quantity < @Threshold
    ORDER BY s.store_id, s.quantity;
END;

exec sp_GenerateRestockList

------------------------------------
--sp_CompareSalesYearOverYear
--Input: @year1, @year2
--Output: Revenue and order count comparison per month
CREATE PROCEDURE sp_CompareSalesYearOverYear
    @year1 INT,
    @year2 INT
AS
BEGIN
    SELECT
        MONTH(o.order_date) AS month,
        YEAR(o.order_date) AS year,
        SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS revenue,
        COUNT(DISTINCT o.order_id) AS orders
    FROM sales.Orders o
    JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    WHERE YEAR(o.order_date) IN (@year1, @year2)
    GROUP BY MONTH(o.order_date), YEAR(o.order_date)
    ORDER BY month, year;
END;

----------------------------



CREATE PROCEDURE sp_GetCustomerProfile
    @CustomerId INT
AS
BEGIN
    -- Return total orders and total spend by the customer
    SELECT 
        c.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        COUNT(DISTINCT o.order_id) AS total_orders,
        SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS total_spent
    FROM sales.Customers c
    JOIN sales.Orders o ON c.customer_id = o.customer_id
    JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    WHERE c.customer_id = @CustomerId
    GROUP BY c.customer_id, c.first_name, c.last_name;

    -- Return the top 3 most frequently bought products
    SELECT TOP 3
        p.product_id,
        p.product_name,
        SUM(oi.quantity) AS total_quantity
    FROM sales.Orders o
    JOIN sales.OrderItems oi ON o.order_id = oi.order_id
    JOIN production.Products p ON oi.product_id = p.product_id
    WHERE o.customer_id = @CustomerId
    GROUP BY p.product_id, p.product_name
    ORDER BY total_quantity DESC;
END;

EXEC sp_GetCustomerProfile @CustomerId = 101;
-----------------------------------------------
--addition--

CREATE PROCEDURE sp_StaffRevenueContribution
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    SELECT 
        s.First_Name,
        SUM(oi.Quantity * oi.List_price) AS RevenueGenerated
    FROM 
        sales.Orders o
    JOIN sales.Staffs s ON o.Staff_ID = s.Staff_id
    JOIN sales.OrderItems oi ON o.Order_ID = oi.Order_ID
    WHERE 
        o.Order_Date BETWEEN @StartDate AND @EndDate
        AND o.Order_Status = 3 -- assuming 3 = Completed
    GROUP BY s.First_Name;
END;
EXEC sp_StaffRevenueContribution 
    @StartDate = '2016-01-01', 
    @EndDate = '2018-12-31';



